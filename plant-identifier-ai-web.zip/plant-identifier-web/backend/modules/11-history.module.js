/**
 * MODULE 11 - HISTORY
 * ---------------------------------------------------------
 * Read access to a user's past plant identifications and
 * disease diagnoses (written by modules 06 and 07).
 * Mounted under /api/history
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');

async function listHistory(userId, { type } = {}) {
  const database = db.readDB();
  let items = database.history.filter(h => h.userId === userId);
  if (type === 'identify' || type === 'disease') {
    items = items.filter(h => h.type === type);
  }
  items.sort((a, b) => b.createdAt - a.createdAt);
  return { status: 200, body: { history: items } };
}

async function getHistoryItem(userId, id) {
  const database = db.readDB();
  const item = database.history.find(h => h.id === id && h.userId === userId);
  if (!item) return { status: 404, body: { error: 'History item not found.' } };
  return { status: 200, body: { item } };
}

async function deleteHistoryItem(userId, id) {
  const database = db.readDB();
  const before = database.history.length;
  database.history = database.history.filter(h => !(h.id === id && h.userId === userId));
  if (database.history.length === before) {
    return { status: 404, body: { error: 'History item not found.' } };
  }
  await db.writeDB(database);
  return { status: 200, body: { message: 'History item deleted.' } };
}

module.exports = { listHistory, getHistoryItem, deleteHistoryItem };
