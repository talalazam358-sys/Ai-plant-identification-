/**
 * MODULE 07 - DISEASE DETECTION (PLANT DOCTOR)
 * ---------------------------------------------------------
 * Takes a base64 photo of a possibly-sick plant and asks
 * Gemini to diagnose it. Mounted under /api/disease
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');
const gemini = require('./05-gemini.service');

const SYSTEM_INSTRUCTION = `You are "Plant Doctor", an AI specializing in diagnosing plant diseases and
pest problems from photos. Respond ONLY with strict JSON matching this schema, no markdown fences:
{
  "diseaseName": string,
  "severity": "Low" | "Moderate" | "High" | "None Detected",
  "symptoms": string,
  "treatment": string,
  "confidenceScore": number (0 to 1)
}
If the plant looks healthy, set diseaseName to "Healthy Plant", severity to "None Detected", and
explain briefly in symptoms why no issue was found.`;

async function diagnosePlant({ userId, imageBase64, mimeType, notes }) {
  if (!imageBase64) {
    return { status: 400, body: { error: 'An image is required.' } };
  }

  const prompt = notes
    ? `Diagnose this plant. Additional context from the gardener: ${notes}`
    : 'Diagnose this plant for diseases or pests.';

  let resultText;
  try {
    resultText = await gemini.generateFromImage({
      prompt,
      imageBase64,
      mimeType: mimeType || 'image/jpeg',
      systemInstruction: SYSTEM_INSTRUCTION,
      jsonMode: true
    });
  } catch (err) {
    return { status: err.status || 502, body: { error: err.message } };
  }

  const parsed = gemini.safeParseJSON(resultText);
  if (!parsed) {
    return { status: 502, body: { error: 'Could not parse the AI response. Please try again.' } };
  }

  const database = db.readDB();
  const entry = {
    id: db.genId('hist'),
    userId,
    type: 'disease',
    result: parsed,
    createdAt: Date.now()
  };
  database.history.unshift(entry);
  await db.writeDB(database);

  return { status: 200, body: { result: parsed, historyId: entry.id } };
}

module.exports = { diagnosePlant };
