/**
 * MODULE 08 - BOTANICAL ESSAY GENERATOR
 * ---------------------------------------------------------
 * Generates an educational essay about a plant/topic in
 * English or Urdu, and saves it to the user's essay list.
 * Mounted under /api/essay
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');
const gemini = require('./05-gemini.service');

async function generateEssay({ userId, topic, language }) {
  if (!topic || !topic.trim()) {
    return { status: 400, body: { error: 'A plant or topic name is required.' } };
  }
  const lang = language === 'ur' ? 'Urdu' : 'English';

  const systemInstruction = `You are a knowledgeable botanist and science writer. Write clear,
well-structured, factually careful essays for curious home gardeners. Use short paragraphs and
a friendly but informative tone. Write entirely in ${lang}.`;

  const prompt = `Write an educational botanical essay (about 300-450 words) about: "${topic}".
Cover origin, notable characteristics, growing conditions, and one interesting fact.`;

  let text;
  try {
    text = await gemini.generateText({ prompt, systemInstruction, temperature: 0.7, jsonMode: false });
  } catch (err) {
    return { status: err.status || 502, body: { error: err.message } };
  }

  const database = db.readDB();
  const entry = {
    id: db.genId('essay'),
    userId,
    topic,
    language: lang,
    content: text,
    createdAt: Date.now()
  };
  database.essays.unshift(entry);
  await db.writeDB(database);

  return { status: 200, body: { essay: entry } };
}

async function listEssays(userId) {
  const database = db.readDB();
  const essays = database.essays.filter(e => e.userId === userId);
  return { status: 200, body: { essays } };
}

async function deleteEssay(userId, essayId) {
  const database = db.readDB();
  const before = database.essays.length;
  database.essays = database.essays.filter(e => !(e.id === essayId && e.userId === userId));
  if (database.essays.length === before) {
    return { status: 404, body: { error: 'Essay not found.' } };
  }
  await db.writeDB(database);
  return { status: 200, body: { message: 'Essay deleted.' } };
}

module.exports = { generateEssay, listEssays, deleteEssay };
