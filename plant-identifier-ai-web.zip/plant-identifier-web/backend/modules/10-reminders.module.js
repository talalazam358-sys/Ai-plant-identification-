/**
 * MODULE 10 - CARE REMINDERS
 * ---------------------------------------------------------
 * CRUD for watering / fertilizing / repotting reminders.
 * Mounted under /api/reminders
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');

const VALID_TYPES = ['watering', 'fertilizing', 'repotting', 'pruning', 'other'];

async function createReminder({ userId, plantName, type, intervalDays, notes, nextDue }) {
  if (!plantName || !plantName.trim()) {
    return { status: 400, body: { error: 'Plant name is required.' } };
  }
  const reminderType = VALID_TYPES.includes(type) ? type : 'other';
  const interval = Number.isFinite(Number(intervalDays)) && Number(intervalDays) > 0
    ? Number(intervalDays)
    : 7;

  const database = db.readDB();
  const entry = {
    id: db.genId('rem'),
    userId,
    plantName: plantName.trim(),
    type: reminderType,
    intervalDays: interval,
    notes: notes || '',
    nextDue: nextDue ? new Date(nextDue).getTime() : Date.now() + interval * 86400000,
    createdAt: Date.now(),
    active: true
  };
  database.reminders.push(entry);
  await db.writeDB(database);
  return { status: 201, body: { reminder: entry } };
}

async function listReminders(userId) {
  const database = db.readDB();
  const reminders = database.reminders
    .filter(r => r.userId === userId)
    .sort((a, b) => a.nextDue - b.nextDue);
  return { status: 200, body: { reminders } };
}

async function updateReminder(userId, id, updates) {
  const database = db.readDB();
  const reminder = database.reminders.find(r => r.id === id && r.userId === userId);
  if (!reminder) return { status: 404, body: { error: 'Reminder not found.' } };

  if (typeof updates.plantName === 'string' && updates.plantName.trim()) reminder.plantName = updates.plantName.trim();
  if (VALID_TYPES.includes(updates.type)) reminder.type = updates.type;
  if (Number.isFinite(Number(updates.intervalDays)) && Number(updates.intervalDays) > 0) {
    reminder.intervalDays = Number(updates.intervalDays);
  }
  if (typeof updates.notes === 'string') reminder.notes = updates.notes;
  if (typeof updates.active === 'boolean') reminder.active = updates.active;
  if (updates.nextDue) reminder.nextDue = new Date(updates.nextDue).getTime();

  await db.writeDB(database);
  return { status: 200, body: { reminder } };
}

/** Mark a reminder as "done" now — pushes nextDue forward by its interval */
async function completeReminder(userId, id) {
  const database = db.readDB();
  const reminder = database.reminders.find(r => r.id === id && r.userId === userId);
  if (!reminder) return { status: 404, body: { error: 'Reminder not found.' } };
  reminder.nextDue = Date.now() + reminder.intervalDays * 86400000;
  reminder.lastCompletedAt = Date.now();
  await db.writeDB(database);
  return { status: 200, body: { reminder } };
}

async function deleteReminder(userId, id) {
  const database = db.readDB();
  const before = database.reminders.length;
  database.reminders = database.reminders.filter(r => !(r.id === id && r.userId === userId));
  if (database.reminders.length === before) {
    return { status: 404, body: { error: 'Reminder not found.' } };
  }
  await db.writeDB(database);
  return { status: 200, body: { message: 'Reminder deleted.' } };
}

module.exports = { createReminder, listReminders, updateReminder, completeReminder, deleteReminder };
