/**
 * MODULE 05 - GEMINI AI SERVICE
 * ---------------------------------------------------------
 * Thin wrapper around Google's Gemini "generateContent" REST
 * endpoint using Node's built-in https module — no SDK/npm
 * dependency required. Every AI-powered module (identify,
 * disease, essay, chat) calls through here.
 * ---------------------------------------------------------
 */

const https = require('https');

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_HOST = 'generativelanguage.googleapis.com';

class GeminiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'GeminiError';
    this.status = status || 502;
  }
}

function isConfigured() {
  return Boolean(GEMINI_API_KEY);
}

/**
 * Low-level POST to the Gemini API.
 * @param {object} requestBody - Gemini generateContent request body
 * @returns {Promise<object>} parsed JSON response
 */
function callGemini(requestBody) {
  return new Promise((resolve, reject) => {
    if (!isConfigured()) {
      reject(new GeminiError(
        'GEMINI_API_KEY is not set on the server. Add it to your .env file to enable AI features.',
        500
      ));
      return;
    }

    const payload = JSON.stringify(requestBody);
    const options = {
      hostname: GEMINI_HOST,
      path: `/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => {
        let parsed;
        try {
          parsed = JSON.parse(data);
        } catch (e) {
          reject(new GeminiError('Gemini returned a non-JSON response.', 502));
          return;
        }
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(parsed);
        } else {
          const msg = parsed?.error?.message || `Gemini API error (${res.statusCode})`;
          reject(new GeminiError(msg, res.statusCode));
        }
      });
    });

    req.on('error', err => reject(new GeminiError(err.message, 502)));
    req.write(payload);
    req.end();
  });
}

/** Pull plain text out of a Gemini response object */
function extractText(response) {
  const parts = response?.candidates?.[0]?.content?.parts || [];
  return parts.map(p => p.text || '').join('').trim();
}

/**
 * Ask Gemini a text-only question with an optional system instruction,
 * and get back plain text.
 */
async function generateText({ prompt, systemInstruction, temperature = 0.6, jsonMode = false }) {
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature,
      ...(jsonMode ? { responseMimeType: 'application/json' } : {})
    }
  };
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] };
  }
  const response = await callGemini(body);
  return extractText(response);
}

/**
 * Ask Gemini about an image (base64) with a text prompt.
 * Returns plain text (JSON string if jsonMode is used).
 */
async function generateFromImage({ prompt, imageBase64, mimeType = 'image/jpeg', systemInstruction, jsonMode = true }) {
  const body = {
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { mimeType, data: imageBase64 } }
        ]
      }
    ],
    generationConfig: {
      temperature: 0.4,
      ...(jsonMode ? { responseMimeType: 'application/json' } : {})
    }
  };
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] };
  }
  const response = await callGemini(body);
  return extractText(response);
}

/** Safely parse JSON text returned by Gemini, with a fallback */
function safeParseJSON(text, fallback = null) {
  try {
    return JSON.parse(text);
  } catch (e) {
    // Gemini sometimes wraps JSON in ```json fences despite instructions
    const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    try {
      return JSON.parse(cleaned);
    } catch (e2) {
      return fallback;
    }
  }
}

module.exports = {
  isConfigured,
  generateText,
  generateFromImage,
  safeParseJSON,
  GeminiError,
  GEMINI_MODEL
};
