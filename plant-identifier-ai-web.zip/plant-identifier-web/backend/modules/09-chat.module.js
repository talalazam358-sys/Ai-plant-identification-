/**
 * MODULE 09 - AI BOTANIST CHAT
 * ---------------------------------------------------------
 * 24/7 conversational chat with a Gemini-powered botanist
 * persona. Keeps short per-user chat history for context.
 * Mounted under /api/chat
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');
const gemini = require('./05-gemini.service');

const SYSTEM_INSTRUCTION = `You are "Sprout", a warm, knowledgeable AI botanist chat assistant inside
a plant-care app. Give practical, concise gardening advice (a few short paragraphs at most).
If asked something outside plants/gardening, gently steer back to plant topics.`;

const MAX_HISTORY_MESSAGES = 12;

async function sendMessage({ userId, message }) {
  if (!message || !message.trim()) {
    return { status: 400, body: { error: 'A message is required.' } };
  }

  const database = db.readDB();
  const priorMessages = database.chats
    .filter(c => c.userId === userId)
    .slice(-MAX_HISTORY_MESSAGES);

  const transcript = priorMessages
    .map(m => `${m.role === 'user' ? 'Gardener' : 'Sprout'}: ${m.text}`)
    .join('\n');

  const prompt = transcript
    ? `Conversation so far:\n${transcript}\n\nGardener: ${message}\n\nRespond as Sprout.`
    : `Gardener: ${message}\n\nRespond as Sprout.`;

  let reply;
  try {
    reply = await gemini.generateText({ prompt, systemInstruction: SYSTEM_INSTRUCTION, temperature: 0.75 });
  } catch (err) {
    return { status: err.status || 502, body: { error: err.message } };
  }

  const now = Date.now();
  database.chats.push({ id: db.genId('chat'), userId, role: 'user', text: message, createdAt: now });
  database.chats.push({ id: db.genId('chat'), userId, role: 'assistant', text: reply, createdAt: now + 1 });
  await db.writeDB(database);

  return { status: 200, body: { reply } };
}

async function getHistory(userId) {
  const database = db.readDB();
  const messages = database.chats.filter(c => c.userId === userId);
  return { status: 200, body: { messages } };
}

async function clearHistory(userId) {
  const database = db.readDB();
  database.chats = database.chats.filter(c => c.userId !== userId);
  await db.writeDB(database);
  return { status: 200, body: { message: 'Chat history cleared.' } };
}

module.exports = { sendMessage, getHistory, clearHistory };
