/**
 * MODULE 12 - PLANT ENCYCLOPEDIA
 * ---------------------------------------------------------
 * Read-only, bilingual (English/Urdu) reference library of
 * common plants — ported from the original app's built-in
 * dataset. Mounted under /api/encyclopedia
 * ---------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');

const SEED_FILE = path.join(__dirname, '..', 'data', 'encyclopedia_seed.json');

let cache = null;
function loadPlants() {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(SEED_FILE, 'utf-8'));
  } catch (err) {
    console.error('[encyclopedia] Failed to load seed data:', err.message);
    cache = [];
  }
  return cache;
}

async function listPlants({ search } = {}) {
  const plants = loadPlants();
  if (!search || !search.trim()) {
    return { status: 200, body: { plants } };
  }
  const q = search.trim().toLowerCase();
  const filtered = plants.filter(p =>
    p.name.toLowerCase().includes(q) ||
    (p.scientificName || '').toLowerCase().includes(q) ||
    (p.family || '').toLowerCase().includes(q)
  );
  return { status: 200, body: { plants: filtered } };
}

async function getPlant(id) {
  const plants = loadPlants();
  const plant = plants.find(p => p.id === id);
  if (!plant) return { status: 404, body: { error: 'Plant not found in encyclopedia.' } };
  return { status: 200, body: { plant } };
}

module.exports = { listPlants, getPlant };
