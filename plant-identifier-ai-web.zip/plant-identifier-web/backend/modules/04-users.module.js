/**
 * MODULE 04 - USERS / GARDENER PROFILE
 * ---------------------------------------------------------
 * Get + update the logged-in user's profile (name, bio, avatar,
 * gardener level). Mounted under /api/users/*
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');

async function getProfile(userId) {
  const database = db.readDB();
  const user = database.users.find(u => u.id === userId);
  if (!user) return { status: 404, body: { error: 'User not found.' } };
  const { passwordHash, salt, ...safeUser } = user;

  const identifications = database.history.filter(h => h.userId === userId && h.type === 'identify').length;
  const diagnoses = database.history.filter(h => h.userId === userId && h.type === 'disease').length;
  const reminders = database.reminders.filter(r => r.userId === userId).length;

  return {
    status: 200,
    body: { user: safeUser, stats: { identifications, diagnoses, reminders } }
  };
}

async function updateProfile(userId, { name, bio, avatar, gardenerLevel }) {
  const database = db.readDB();
  const user = database.users.find(u => u.id === userId);
  if (!user) return { status: 404, body: { error: 'User not found.' } };

  if (typeof name === 'string' && name.trim()) user.name = name.trim();
  if (typeof bio === 'string') user.bio = bio.slice(0, 500);
  if (typeof avatar === 'string') user.avatar = avatar; // data-URL or emoji, kept small
  if (typeof gardenerLevel === 'string') {
    const allowed = ['Beginner', 'Hobbyist', 'Experienced', 'Expert'];
    if (allowed.includes(gardenerLevel)) user.gardenerLevel = gardenerLevel;
  }

  await db.writeDB(database);
  const { passwordHash, salt, ...safeUser } = user;
  return { status: 200, body: { user: safeUser } };
}

module.exports = { getProfile, updateProfile };
