/**
 * MODULE 01 - DATABASE
 * ---------------------------------------------------------
 * Lightweight, dependency-free JSON file "database".
 * Uses only Node core (fs/path) so the app runs with ZERO
 * npm installs. Good enough for a demo / small deployment.
 * Swap this module out for MongoDB/Postgres later if needed —
 * every other module only talks to the functions exported here.
 * ---------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const DEFAULT_SCHEMA = {
  users: [],          // { id, name, email, passwordHash, salt, createdAt, avatar, bio }
  sessions: [],        // { token, userId, createdAt, expiresAt }
  resetTokens: [],     // { token, userId, expiresAt }
  history: [],          // plant identification + disease results
  reminders: [],         // watering / fertilizing reminders
  chats: [],               // AI botanist chat messages
  essays: []                 // generated botanical essays
};

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_SCHEMA, null, 2));
  }
}

function readDB() {
  ensureStore();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    // Merge in any keys added in newer versions of the schema
    return { ...DEFAULT_SCHEMA, ...parsed };
  } catch (err) {
    console.error('[database] Failed to read DB, resetting file:', err.message);
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_SCHEMA, null, 2));
    return JSON.parse(JSON.stringify(DEFAULT_SCHEMA));
  }
}

let writeQueue = Promise.resolve();
function writeDB(db) {
  // Serialize writes so concurrent requests never corrupt the file
  writeQueue = writeQueue.then(() => {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  });
  return writeQueue;
}

function genId(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

module.exports = {
  ensureStore,
  readDB,
  writeDB,
  genId
};
