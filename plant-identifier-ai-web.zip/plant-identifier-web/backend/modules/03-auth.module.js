/**
 * MODULE 03 - AUTHENTICATION
 * ---------------------------------------------------------
 * Handles: register, login, logout, forgot-password, reset-password.
 * Routes are mounted under /api/auth/*
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');
const security = require('./02-security.module');

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

async function register({ name, email, password }) {
  if (!name || !email || !password) {
    return { status: 400, body: { error: 'Name, email and password are required.' } };
  }
  if (!isValidEmail(email)) {
    return { status: 400, body: { error: 'Please enter a valid email address.' } };
  }
  if (password.length < 6) {
    return { status: 400, body: { error: 'Password must be at least 6 characters.' } };
  }

  const database = db.readDB();
  const existing = database.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return { status: 409, body: { error: 'An account with this email already exists.' } };
  }

  const { salt, hash } = security.hashPassword(password);
  const user = {
    id: db.genId('user'),
    name,
    email: email.toLowerCase(),
    passwordHash: hash,
    salt,
    avatar: null,
    bio: '',
    gardenerLevel: 'Beginner',
    createdAt: Date.now()
  };
  database.users.push(user);
  await db.writeDB(database);

  const token = await security.createSession(user.id);
  const { passwordHash, salt: _s, ...safeUser } = user;
  return { status: 201, body: { token, user: safeUser } };
}

async function login({ email, password }) {
  if (!email || !password) {
    return { status: 400, body: { error: 'Email and password are required.' } };
  }
  const database = db.readDB();
  const user = database.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user || !security.verifyPassword(password, user.salt, user.passwordHash)) {
    return { status: 401, body: { error: 'Invalid email or password.' } };
  }
  const token = await security.createSession(user.id);
  const { passwordHash, salt, ...safeUser } = user;
  return { status: 200, body: { token, user: safeUser } };
}

async function logout(token) {
  const database = db.readDB();
  database.sessions = database.sessions.filter(s => s.token !== token);
  await db.writeDB(database);
  return { status: 200, body: { message: 'Logged out.' } };
}

async function forgotPassword({ email }) {
  const database = db.readDB();
  const user = database.users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  // Always respond the same way so we don't leak which emails are registered
  const generic = { status: 200, body: { message: 'If that email exists, a reset link has been generated.' } };
  if (!user) return generic;

  const token = await security.createResetToken(user.id);
  // In a real deployment this would be emailed. For this self-contained
  // demo we return it directly so the "Forgot Password" flow is fully
  // testable without an SMTP server.
  generic.body.resetToken = token;
  generic.body.resetTtlMinutes = security.RESET_TTL_MS / 60000;
  return generic;
}

async function resetPassword({ token, newPassword }) {
  if (!token || !newPassword) {
    return { status: 400, body: { error: 'Token and new password are required.' } };
  }
  if (newPassword.length < 6) {
    return { status: 400, body: { error: 'Password must be at least 6 characters.' } };
  }
  const database = db.readDB();
  const record = database.resetTokens.find(r => r.token === token);
  if (!record || record.expiresAt < Date.now()) {
    return { status: 400, body: { error: 'Reset token is invalid or has expired.' } };
  }
  const user = database.users.find(u => u.id === record.userId);
  if (!user) {
    return { status: 400, body: { error: 'User not found.' } };
  }
  const { salt, hash } = security.hashPassword(newPassword);
  user.salt = salt;
  user.passwordHash = hash;
  database.resetTokens = database.resetTokens.filter(r => r.token !== token);
  // Invalidate existing sessions on password reset
  database.sessions = database.sessions.filter(s => s.userId !== user.id);
  await db.writeDB(database);
  return { status: 200, body: { message: 'Password has been reset. Please log in.' } };
}

module.exports = { register, login, logout, forgotPassword, resetPassword };
