/**
 * MODULE 06 - PLANT IDENTIFICATION
 * ---------------------------------------------------------
 * Takes a base64 photo, asks Gemini to identify the plant,
 * and saves the result to the user's history.
 * Mounted under /api/identify
 * ---------------------------------------------------------
 */

const db = require('./01-database.module');
const gemini = require('./05-gemini.service');

const SYSTEM_INSTRUCTION = `You are an expert botanist embedded in a plant-identification app.
Given a photo of a plant, identify it and respond ONLY with strict JSON matching this schema,
no markdown fences, no extra commentary:
{
  "name": string,
  "scientificName": string,
  "family": string,
  "description": string,
  "careInstructions": string,
  "waterRequirements": string,
  "sunlightRequirements": string,
  "confidenceScore": number (0 to 1)
}
If the photo does not clearly contain a plant, still return your best-guess JSON but set
confidenceScore below 0.3 and mention the uncertainty in "description".`;

async function identifyPlant({ userId, imageBase64, mimeType }) {
  if (!imageBase64) {
    return { status: 400, body: { error: 'An image is required.' } };
  }

  let resultText;
  try {
    resultText = await gemini.generateFromImage({
      prompt: 'Identify this plant.',
      imageBase64,
      mimeType: mimeType || 'image/jpeg',
      systemInstruction: SYSTEM_INSTRUCTION,
      jsonMode: true
    });
  } catch (err) {
    return { status: err.status || 502, body: { error: err.message } };
  }

  const parsed = gemini.safeParseJSON(resultText);
  if (!parsed) {
    return { status: 502, body: { error: 'Could not parse the AI response. Please try again.' } };
  }

  const database = db.readDB();
  const entry = {
    id: db.genId('hist'),
    userId,
    type: 'identify',
    result: parsed,
    createdAt: Date.now()
  };
  database.history.unshift(entry);
  await db.writeDB(database);

  return { status: 200, body: { result: parsed, historyId: entry.id } };
}

module.exports = { identifyPlant };
