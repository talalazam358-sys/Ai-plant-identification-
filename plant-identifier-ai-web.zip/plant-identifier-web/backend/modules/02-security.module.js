/**
 * MODULE 02 - SECURITY
 * ---------------------------------------------------------
 * Password hashing (scrypt, built into Node's crypto module —
 * no bcrypt/argon2 dependency needed) + session token helpers.
 * ---------------------------------------------------------
 */

const crypto = require('crypto');
const db = require('./01-database.module');

const TOKEN_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days
const RESET_TTL_MS = 1000 * 60 * 30;          // 30 minutes

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, expectedHash) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(expectedHash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function createToken() {
  return crypto.randomBytes(32).toString('hex');
}

async function createSession(userId) {
  const database = db.readDB();
  const token = createToken();
  database.sessions.push({
    token,
    userId,
    createdAt: Date.now(),
    expiresAt: Date.now() + TOKEN_TTL_MS
  });
  await db.writeDB(database);
  return token;
}

async function createResetToken(userId) {
  const database = db.readDB();
  const token = createToken();
  database.resetTokens.push({
    token,
    userId,
    expiresAt: Date.now() + RESET_TTL_MS
  });
  await db.writeDB(database);
  return token;
}

function getUserFromToken(token) {
  if (!token) return null;
  const database = db.readDB();
  const session = database.sessions.find(s => s.token === token);
  if (!session) return null;
  if (session.expiresAt < Date.now()) return null;
  const user = database.users.find(u => u.id === session.userId);
  if (!user) return null;
  const { passwordHash, salt, ...safeUser } = user;
  return safeUser;
}

/** Extract Bearer token from an incoming request */
function extractToken(req) {
  const header = req.headers['authorization'] || '';
  if (header.startsWith('Bearer ')) return header.slice(7).trim();
  return null;
}

/** Throws-free auth guard: returns user object or null */
function authenticate(req) {
  const token = extractToken(req);
  return getUserFromToken(token);
}

module.exports = {
  hashPassword,
  verifyPassword,
  createToken,
  createSession,
  createResetToken,
  getUserFromToken,
  extractToken,
  authenticate,
  RESET_TTL_MS
};
