/**
 * PLANT IDENTIFIER AI - WEB EDITION
 * SERVER ENTRY POINT
 * ---------------------------------------------------------
 * Pure Node.js HTTP server (no Express, no npm install needed).
 * - Serves the static frontend from /frontend
 * - Routes /api/* to the 12 backend modules
 * - Parses JSON bodies (including base64 images) itself
 * - Enforces auth on protected routes via Bearer token
 *
 * Run with:  node backend/server.js
 * ---------------------------------------------------------
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { loadEnv } = require('./config');

loadEnv();

const security = require('./modules/02-security.module');
const authModule = require('./modules/03-auth.module');
const usersModule = require('./modules/04-users.module');
const gemini = require('./modules/05-gemini.service');
const identifyModule = require('./modules/06-identify.module');
const diseaseModule = require('./modules/07-disease.module');
const essayModule = require('./modules/08-essay.module');
const chatModule = require('./modules/09-chat.module');
const remindersModule = require('./modules/10-reminders.module');
const historyModule = require('./modules/11-history.module');
const encyclopediaModule = require('./modules/12-encyclopedia.module');

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');
const MAX_BODY_BYTES = 20 * 1024 * 1024; // 20MB, generous enough for a base64 photo

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2'
};

function sendJSON(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
  });
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('Payload too large.'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (chunks.length === 0) return resolve({});
      const raw = Buffer.concat(chunks).toString('utf-8');
      if (!raw.trim()) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        reject(Object.assign(new Error('Invalid JSON body.'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function requireAuth(req) {
  const user = security.authenticate(req);
  if (!user) {
    const err = new Error('Unauthorized. Please log in again.');
    err.status = 401;
    throw err;
  }
  return user;
}

/* -------------------------- static file serving -------------------------- */

function serveStatic(req, res) {
  let reqPath = decodeURIComponent(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';

  const filePath = path.normalize(path.join(FRONTEND_DIR, reqPath));
  // Prevent path traversal outside the frontend directory
  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      // SPA-friendly fallback: unknown routes -> index.html isn't appropriate
      // here since we use multi-page HTML, so just 404.
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<h1>404 - Page not found</h1><a href="/">Go home</a>');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

/* ------------------------------- API router ------------------------------- */

async function apiRouter(req, res, pathname) {
  const segments = pathname.split('/').filter(Boolean); // ['api', 'auth', 'login']
  const [, resource, action, id] = segments;
  const method = req.method;

  try {
    // ---------- AUTH (public) ----------
    if (resource === 'auth') {
      const body = method !== 'GET' ? await readBody(req) : {};
      if (action === 'register' && method === 'POST') return sendJSON(res, ...respond(await authModule.register(body)));
      if (action === 'login' && method === 'POST') return sendJSON(res, ...respond(await authModule.login(body)));
      if (action === 'logout' && method === 'POST') {
        const token = security.extractToken(req);
        return sendJSON(res, ...respond(await authModule.logout(token)));
      }
      if (action === 'forgot-password' && method === 'POST') return sendJSON(res, ...respond(await authModule.forgotPassword(body)));
      if (action === 'reset-password' && method === 'POST') return sendJSON(res, ...respond(await authModule.resetPassword(body)));
      if (action === 'me' && method === 'GET') {
        const user = requireAuth(req);
        return sendJSON(res, 200, { user });
      }
      return sendJSON(res, 404, { error: 'Auth endpoint not found.' });
    }

    // Everything below requires a logged-in user
    const user = requireAuth(req);

    // ---------- USERS / PROFILE ----------
    if (resource === 'users') {
      if (action === 'profile' && method === 'GET') return sendJSON(res, ...respond(await usersModule.getProfile(user.id)));
      if (action === 'profile' && method === 'PUT') {
        const body = await readBody(req);
        return sendJSON(res, ...respond(await usersModule.updateProfile(user.id, body)));
      }
      return sendJSON(res, 404, { error: 'Users endpoint not found.' });
    }

    // ---------- IDENTIFY ----------
    if (resource === 'identify' && method === 'POST') {
      const body = await readBody(req);
      return sendJSON(res, ...respond(await identifyModule.identifyPlant({ userId: user.id, ...body })));
    }

    // ---------- DISEASE ----------
    if (resource === 'disease' && method === 'POST') {
      const body = await readBody(req);
      return sendJSON(res, ...respond(await diseaseModule.diagnosePlant({ userId: user.id, ...body })));
    }

    // ---------- ESSAY ----------
    if (resource === 'essay') {
      if (method === 'POST' && !action) {
        const body = await readBody(req);
        return sendJSON(res, ...respond(await essayModule.generateEssay({ userId: user.id, ...body })));
      }
      if (method === 'GET' && !action) return sendJSON(res, ...respond(await essayModule.listEssays(user.id)));
      if (method === 'DELETE' && action) return sendJSON(res, ...respond(await essayModule.deleteEssay(user.id, action)));
      return sendJSON(res, 404, { error: 'Essay endpoint not found.' });
    }

    // ---------- CHAT ----------
    if (resource === 'chat') {
      if (method === 'POST' && !action) {
        const body = await readBody(req);
        return sendJSON(res, ...respond(await chatModule.sendMessage({ userId: user.id, ...body })));
      }
      if (method === 'GET' && !action) return sendJSON(res, ...respond(await chatModule.getHistory(user.id)));
      if (method === 'DELETE' && action === 'clear') return sendJSON(res, ...respond(await chatModule.clearHistory(user.id)));
      return sendJSON(res, 404, { error: 'Chat endpoint not found.' });
    }

    // ---------- REMINDERS ----------
    if (resource === 'reminders') {
      if (method === 'POST' && !action) {
        const body = await readBody(req);
        return sendJSON(res, ...respond(await remindersModule.createReminder({ userId: user.id, ...body })));
      }
      if (method === 'GET' && !action) return sendJSON(res, ...respond(await remindersModule.listReminders(user.id)));
      if (method === 'PUT' && action) {
        const body = await readBody(req);
        return sendJSON(res, ...respond(await remindersModule.updateReminder(user.id, action, body)));
      }
      if (method === 'POST' && action && id === 'complete') {
        return sendJSON(res, ...respond(await remindersModule.completeReminder(user.id, action)));
      }
      if (method === 'DELETE' && action) return sendJSON(res, ...respond(await remindersModule.deleteReminder(user.id, action)));
      return sendJSON(res, 404, { error: 'Reminders endpoint not found.' });
    }

    // ---------- HISTORY ----------
    if (resource === 'history') {
      if (method === 'GET' && !action) {
        const url = new URL(req.url, `http://${req.headers.host}`);
        return sendJSON(res, ...respond(await historyModule.listHistory(user.id, { type: url.searchParams.get('type') })));
      }
      if (method === 'GET' && action) return sendJSON(res, ...respond(await historyModule.getHistoryItem(user.id, action)));
      if (method === 'DELETE' && action) return sendJSON(res, ...respond(await historyModule.deleteHistoryItem(user.id, action)));
      return sendJSON(res, 404, { error: 'History endpoint not found.' });
    }

    // ---------- ENCYCLOPEDIA ----------
    if (resource === 'encyclopedia') {
      if (method === 'GET' && !action) {
        const url = new URL(req.url, `http://${req.headers.host}`);
        return sendJSON(res, ...respond(await encyclopediaModule.listPlants({ search: url.searchParams.get('search') })));
      }
      if (method === 'GET' && action) return sendJSON(res, ...respond(await encyclopediaModule.getPlant(action)));
      return sendJSON(res, 404, { error: 'Encyclopedia endpoint not found.' });
    }

    return sendJSON(res, 404, { error: 'Unknown API endpoint.' });
  } catch (err) {
    const status = err.status || 500;
    if (status >= 500) console.error('[server] Unhandled error:', err);
    return sendJSON(res, status, { error: err.message || 'Internal server error.' });
  }
}

function respond(result) {
  return [result.status, result.body];
}

/* --------------------------------- server --------------------------------- */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
    });
    res.end();
    return;
  }

  if (pathname === '/api/health') {
    return sendJSON(res, 200, { status: 'ok', geminiConfigured: gemini.isConfigured(), model: gemini.GEMINI_MODEL });
  }

  if (pathname.startsWith('/api/')) {
    return apiRouter(req, res, pathname);
  }

  return serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log('===========================================');
  console.log('  Plant Identifier AI - Web Edition');
  console.log(`  Server running at: http://localhost:${PORT}`);
  console.log(`  Gemini configured: ${gemini.isConfigured() ? 'YES' : 'NO (set GEMINI_API_KEY in .env)'}`);
  console.log('===========================================');
});
