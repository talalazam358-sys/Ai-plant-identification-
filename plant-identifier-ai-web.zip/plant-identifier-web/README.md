# 🌿 Plant Identifier AI — Web Edition (Classic Theme)

A full-stack website conversion of the original **Plant Identifier AI** Android app.
Same features — plant identification, disease diagnosis, botanical essays, AI chat,
care reminders, encyclopedia, and gardener profiles — now running as a website with
a classic botanical (forest green / gold / parchment) theme.

## ✨ Highlights

- **Zero npm dependencies.** The backend is pure Node.js (`http`, `fs`, `crypto`) —
  just run `node backend/server.js`. Nothing to install, nothing that can break.
- **12 backend modules**, each its own file, each with a single responsibility.
- **12 matching frontend pages**, each its own HTML file + its own JS file.
- **Real authentication**: register, login, logout, forgot/reset password, hashed
  passwords (scrypt), Bearer-token sessions — no third-party auth service required.
- **Classic theme**: custom logo, forest/gold/parchment palette, serif headings.
- **Bilingual encyclopedia & essays** (English / Urdu), carried over from the
  original app's dataset.

## 🧩 The 12 Modules

| # | Module | Backend file | Frontend page |
|---|--------|---------------|----------------|
| 1 | Database (JSON store) | `backend/modules/01-database.module.js` | — (shared infra) |
| 2 | Security (hashing/tokens) | `backend/modules/02-security.module.js` | — (shared infra) |
| 3 | Authentication | `backend/modules/03-auth.module.js` | `login.html`, `register.html`, `forgot-password.html` |
| 4 | User Profile | `backend/modules/04-users.module.js` | `profile.html` |
| 5 | Gemini AI Service | `backend/modules/05-gemini.service.js` | — (shared infra) |
| 6 | Plant Identification | `backend/modules/06-identify.module.js` | `identify.html` |
| 7 | Disease Detection (Plant Doctor) | `backend/modules/07-disease.module.js` | `disease.html` |
| 8 | Botanical Essay Generator | `backend/modules/08-essay.module.js` | `essay.html` |
| 9 | AI Botanist Chat | `backend/modules/09-chat.module.js` | `chat.html` |
| 10 | Care Reminders | `backend/modules/10-reminders.module.js` | `reminders.html` |
| 11 | History | `backend/modules/11-history.module.js` | `history.html` |
| 12 | Encyclopedia | `backend/modules/12-encyclopedia.module.js` | `encyclopedia.html` |

Plus `dashboard.html` as the home/overview page.

## 📁 Project Structure

```
plant-identifier-web/
├── package.json
├── .gitignore
├── backend/
│   ├── server.js              # HTTP server + router (entry point)
│   ├── config.js              # loads .env (no dotenv package needed)
│   ├── .env.example           # copy to .env and add your Gemini key
│   ├── data/
│   │   ├── db.json            # auto-created JSON "database" (gitignored)
│   │   └── encyclopedia_seed.json
│   └── modules/
│       ├── 01-database.module.js
│       ├── 02-security.module.js
│       ├── 03-auth.module.js
│       ├── 04-users.module.js
│       ├── 05-gemini.service.js
│       ├── 06-identify.module.js
│       ├── 07-disease.module.js
│       ├── 08-essay.module.js
│       ├── 09-chat.module.js
│       ├── 10-reminders.module.js
│       ├── 11-history.module.js
│       └── 12-encyclopedia.module.js
└── frontend/
    ├── index.html
    ├── login.html / register.html / forgot-password.html
    ├── dashboard.html
    ├── identify.html / disease.html / essay.html / chat.html
    ├── reminders.html / history.html / encyclopedia.html / profile.html
    ├── css/style.css
    ├── js/  (one file per page, plus shared api.js + layout.js)
    └── assets/logo.svg
```

## 🚀 Getting Started

**Requirements:** Node.js 18 or newer. Nothing else.

1. Unzip the project and open a terminal in the `plant-identifier-web` folder.
2. Copy the env file and add your Gemini API key:
   ```bash
   cp backend/.env.example backend/.env
   ```
   Then open `backend/.env` and set `GEMINI_API_KEY` (get a free key at
   https://aistudio.google.com/app/apikey). Without this key, the app still
   runs fully — login, reminders, encyclopedia, history, profile all work —
   but the AI features (identify, disease, essay, chat) will return a clear
   "not configured" error until you add a key.
3. Start the server:
   ```bash
   npm start
   ```
   (equivalent to `node backend/server.js`)
4. Open your browser to **http://localhost:3000**

That's it — no `npm install` step, because there are no external dependencies.

## 🔐 Authentication Notes

- Passwords are hashed with Node's built-in `scrypt` (never stored in plain text).
- Sessions are random 256-bit Bearer tokens stored server-side with a 7-day expiry.
- "Forgot password" doesn't have an email server wired up in this self-contained
  demo, so the reset token is returned directly in the API response and shown
  on screen — copy it into the "reset token" field on the same page. Wire up a
  real SMTP/email provider in `03-auth.module.js` → `forgotPassword()` for
  production use.

## 🗄️ Data Storage

User accounts, sessions, history, reminders, chat logs, and essays are stored in
`backend/data/db.json` — a single JSON file, auto-created on first run. This
keeps the project dependency-free and easy to inspect/reset (just delete the
file to start fresh). Swap `backend/modules/01-database.module.js` for a real
database (MongoDB, PostgreSQL, etc.) later without touching any other module.

## 🎨 Theme

"Classic Botanical" — deep forest green (`#22432f`), aged gold (`#b8863b`),
parchment cream (`#faf6ec`), serif headings, and a custom hand-coded leaf logo
(`frontend/assets/logo.svg`) — no external icon libraries or stock images used
for branding.

## ⚠️ Production Checklist

This is a fully working demo/learning project. Before deploying publicly:
- Serve over HTTPS and set secure cookie/token handling as needed for your host.
- Add rate limiting on `/api/auth/*` to slow down brute-force attempts.
- Wire up a real email provider for password resets.
- Replace the JSON file database with a proper database for concurrent scale.
- Move `GEMINI_API_KEY` handling to your hosting provider's secret manager.

## 🛠️ Built With

Node.js (core modules only) · HTML5 · CSS3 · Vanilla JavaScript · Google Gemini API
