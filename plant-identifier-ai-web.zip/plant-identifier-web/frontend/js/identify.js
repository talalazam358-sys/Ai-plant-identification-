/**
 * MODULE - PLANT IDENTIFICATION
 * ---------------------------------------------------------
 */

let selectedFile = null;

if (initProtectedPage('identify')) {
  const uploadZone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  const previewImg = document.getElementById('previewImg');
  const identifyBtn = document.getElementById('identifyBtn');
  const alertBox = document.getElementById('alertBox');
  const resultCard = document.getElementById('resultCard');
  const resultBody = document.getElementById('resultBody');

  uploadZone.addEventListener('click', () => fileInput.click());
  uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.style.background = '#f2ead2'; });
  uploadZone.addEventListener('dragleave', () => { uploadZone.style.background = ''; });
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.background = '';
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) handleFile(fileInput.files[0]);
  });

  function handleFile(file) {
    if (!file.type.startsWith('image/')) {
      showAlert(alertBox, 'Please choose an image file.');
      return;
    }
    selectedFile = file;
    previewImg.src = URL.createObjectURL(file);
    previewImg.style.display = 'block';
    identifyBtn.disabled = false;
    alertBox.innerHTML = '';
  }

  identifyBtn.addEventListener('click', async () => {
    if (!selectedFile) return;
    identifyBtn.disabled = true;
    identifyBtn.innerHTML = '<span class="spinner"></span> Analyzing photo...';
    alertBox.innerHTML = '';
    resultCard.style.display = 'none';

    try {
      const imageBase64 = await fileToBase64(selectedFile);
      const { result } = await apiFetch('/identify', {
        method: 'POST',
        body: { imageBase64, mimeType: selectedFile.type }
      });
      renderResult(result);
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      identifyBtn.disabled = false;
      identifyBtn.textContent = 'Identify Plant';
    }
  });

  function renderResult(r) {
    const confidencePct = Math.round((r.confidenceScore || 0) * 100);
    resultBody.innerHTML = `
      <h2 style="margin-bottom:0;">${escapeHtml(r.name || 'Unknown plant')}</h2>
      <p style="color:var(--ink-soft);font-style:italic;margin-top:2px;">${escapeHtml(r.scientificName || '')} · ${escapeHtml(r.family || '')}</p>
      <span class="badge ${confidencePct >= 70 ? 'badge-low' : confidencePct >= 40 ? 'badge-moderate' : 'badge-high'}">${confidencePct}% confidence</span>
      <div class="divider"></div>
      <p><strong>Description:</strong> ${escapeHtml(r.description || '—')}</p>
      <div class="grid grid-2">
        <div><strong>💧 Water:</strong><p>${escapeHtml(r.waterRequirements || '—')}</p></div>
        <div><strong>☀️ Sunlight:</strong><p>${escapeHtml(r.sunlightRequirements || '—')}</p></div>
      </div>
      <p><strong>🪴 Care instructions:</strong> ${escapeHtml(r.careInstructions || '—')}</p>
    `;
    resultCard.style.display = 'block';
  }
}
