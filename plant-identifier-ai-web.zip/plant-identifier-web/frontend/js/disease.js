/**
 * MODULE - DISEASE DETECTION (PLANT DOCTOR)
 * ---------------------------------------------------------
 */

let selectedFile = null;

if (initProtectedPage('disease')) {
  const uploadZone = document.getElementById('uploadZone');
  const fileInput = document.getElementById('fileInput');
  const previewImg = document.getElementById('previewImg');
  const diagnoseBtn = document.getElementById('diagnoseBtn');
  const alertBox = document.getElementById('alertBox');
  const resultCard = document.getElementById('resultCard');
  const resultBody = document.getElementById('resultBody');

  uploadZone.addEventListener('click', () => fileInput.click());
  uploadZone.addEventListener('dragover', (e) => { e.preventDefault(); uploadZone.style.background = '#f2ead2'; });
  uploadZone.addEventListener('dragleave', () => { uploadZone.style.background = ''; });
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.style.background = '';
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', () => {
    if (fileInput.files.length) handleFile(fileInput.files[0]);
  });

  function handleFile(file) {
    if (!file.type.startsWith('image/')) {
      showAlert(alertBox, 'Please choose an image file.');
      return;
    }
    selectedFile = file;
    previewImg.src = URL.createObjectURL(file);
    previewImg.style.display = 'block';
    diagnoseBtn.disabled = false;
    alertBox.innerHTML = '';
  }

  diagnoseBtn.addEventListener('click', async () => {
    if (!selectedFile) return;
    diagnoseBtn.disabled = true;
    diagnoseBtn.innerHTML = '<span class="spinner"></span> Diagnosing...';
    alertBox.innerHTML = '';
    resultCard.style.display = 'none';

    try {
      const imageBase64 = await fileToBase64(selectedFile);
      const notes = document.getElementById('notes').value.trim();
      const { result } = await apiFetch('/disease', {
        method: 'POST',
        body: { imageBase64, mimeType: selectedFile.type, notes }
      });
      renderResult(result);
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      diagnoseBtn.disabled = false;
      diagnoseBtn.textContent = 'Diagnose Plant';
    }
  });

  function severityBadgeClass(sev) {
    const s = (sev || '').toLowerCase();
    if (s.includes('high')) return 'badge-high';
    if (s.includes('moderate')) return 'badge-moderate';
    return 'badge-low';
  }

  function renderResult(r) {
    const confidencePct = Math.round((r.confidenceScore || 0) * 100);
    resultBody.innerHTML = `
      <h2 style="margin-bottom:4px;">${escapeHtml(r.diseaseName || 'Unknown issue')}</h2>
      <span class="badge ${severityBadgeClass(r.severity)}">${escapeHtml(r.severity || 'Unknown')} severity</span>
      <span class="badge badge-low" style="margin-left:6px;">${confidencePct}% confidence</span>
      <div class="divider"></div>
      <p><strong>Symptoms:</strong> ${escapeHtml(r.symptoms || '—')}</p>
      <p><strong>🩹 Recommended treatment:</strong> ${escapeHtml(r.treatment || '—')}</p>
    `;
    resultCard.style.display = 'block';
  }
}
