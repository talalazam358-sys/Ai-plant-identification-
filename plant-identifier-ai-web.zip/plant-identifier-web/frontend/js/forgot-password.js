/**
 * MODULE - FORGOT / RESET PASSWORD
 * ---------------------------------------------------------
 * Note: this demo has no email server wired up, so step 1
 * returns the reset token directly in the response and shows
 * it on screen — copy it into step 2 below.
 * ---------------------------------------------------------
 */

const alertBox = document.getElementById('alertBox');

document.getElementById('requestForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  alertBox.innerHTML = '';
  const email = document.getElementById('email').value.trim();
  const btn = document.getElementById('requestBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Sending...';

  try {
    const data = await apiFetch('/auth/forgot-password', { method: 'POST', body: { email }, auth: false });
    let msg = data.message;
    if (data.resetToken) {
      msg += ` Your reset token (demo mode, no email server configured): <br><code style="user-select:all;">${escapeHtml(data.resetToken)}</code>`;
      document.getElementById('token').value = data.resetToken;
    }
    alertBox.innerHTML = `<div class="alert alert-info">${msg}</div>`;
  } catch (err) {
    showAlert(alertBox, err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send Reset Link';
  }
});

document.getElementById('resetForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const token = document.getElementById('token').value.trim();
  const newPassword = document.getElementById('newPassword').value;
  const btn = document.getElementById('resetBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Resetting...';

  try {
    const data = await apiFetch('/auth/reset-password', { method: 'POST', body: { token, newPassword }, auth: false });
    alertBox.innerHTML = `<div class="alert alert-success">${escapeHtml(data.message)} Redirecting to login...</div>`;
    setTimeout(() => (window.location.href = 'login.html'), 1800);
  } catch (err) {
    showAlert(alertBox, err.message);
    btn.disabled = false;
    btn.textContent = 'Set New Password';
  }
});
