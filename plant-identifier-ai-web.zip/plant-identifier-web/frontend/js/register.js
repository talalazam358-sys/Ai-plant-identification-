/**
 * MODULE - REGISTER
 * ---------------------------------------------------------
 */

if (Auth.isLoggedIn()) {
  window.location.href = 'dashboard.html';
}

const registerForm = document.getElementById('registerForm');
const alertBox = document.getElementById('alertBox');
const submitBtn = document.getElementById('submitBtn');

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  alertBox.innerHTML = '';

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (password !== confirmPassword) {
    showAlert(alertBox, 'Passwords do not match.');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span class="spinner"></span> Creating account...';

  try {
    const data = await apiFetch('/auth/register', { method: 'POST', body: { name, email, password }, auth: false });
    Auth.setToken(data.token);
    Auth.setUser(data.user);
    window.location.href = 'dashboard.html';
  } catch (err) {
    showAlert(alertBox, err.message);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Create Account';
  }
});
