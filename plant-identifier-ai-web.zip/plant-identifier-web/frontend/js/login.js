/**
 * MODULE - LOGIN
 * ---------------------------------------------------------
 */

if (Auth.isLoggedIn()) {
  window.location.href = 'dashboard.html';
}

const loginForm = document.getElementById('loginForm');
const alertBox = document.getElementById('alertBox');
const submitBtn = document.getElementById('submitBtn');

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  alertBox.innerHTML = '';
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span class="spinner"></span> Logging in...';

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  try {
    const data = await apiFetch('/auth/login', { method: 'POST', body: { email, password }, auth: false });
    Auth.setToken(data.token);
    Auth.setUser(data.user);
    window.location.href = 'dashboard.html';
  } catch (err) {
    showAlert(alertBox, err.message);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Log In';
  }
});
