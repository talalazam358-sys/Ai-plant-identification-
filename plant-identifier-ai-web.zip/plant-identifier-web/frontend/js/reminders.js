/**
 * MODULE - CARE REMINDERS
 * ---------------------------------------------------------
 */

if (initProtectedPage('reminders')) {
  const alertBox = document.getElementById('alertBox');
  const addBtn = document.getElementById('addBtn');
  const reminderList = document.getElementById('reminderList');

  addBtn.addEventListener('click', async () => {
    const plantName = document.getElementById('plantName').value.trim();
    const type = document.getElementById('type').value;
    const intervalDays = document.getElementById('intervalDays').value;
    const notes = document.getElementById('notes').value.trim();

    if (!plantName) {
      showAlert(alertBox, 'Please enter a plant name.');
      return;
    }
    addBtn.disabled = true;
    addBtn.innerHTML = '<span class="spinner"></span> Adding...';
    alertBox.innerHTML = '';

    try {
      await apiFetch('/reminders', { method: 'POST', body: { plantName, type, intervalDays, notes } });
      document.getElementById('plantName').value = '';
      document.getElementById('notes').value = '';
      loadReminders();
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      addBtn.disabled = false;
      addBtn.textContent = 'Add Reminder';
    }
  });

  const TYPE_ICONS = { watering: '💧', fertilizing: '🌾', repotting: '🪴', pruning: '✂️', other: '📌' };

  async function loadReminders() {
    try {
      const { reminders } = await apiFetch('/reminders');
      if (reminders.length === 0) {
        reminderList.innerHTML = `<div class="empty-state"><div class="icon">🌼</div>No reminders yet. Add your first one above.</div>`;
        return;
      }
      const now = Date.now();
      reminderList.innerHTML = reminders.map(r => {
        const overdue = r.nextDue < now;
        return `
        <div class="list-item">
          <div>
            <strong>${TYPE_ICONS[r.type] || '📌'} ${escapeHtml(r.plantName)}</strong>
            <div style="font-size:0.82rem;color:${overdue ? 'var(--danger)' : 'var(--ink-soft)'};">
              ${escapeHtml(r.type)} every ${r.intervalDays}d · ${overdue ? 'Overdue since' : 'Due'} ${formatDate(r.nextDue)}
              ${r.notes ? ' · ' + escapeHtml(r.notes) : ''}
            </div>
          </div>
          <div style="display:flex;gap:6px;">
            <button class="btn btn-gold btn-sm" data-done="${r.id}">Done</button>
            <button class="btn btn-danger btn-sm" data-delete="${r.id}">Delete</button>
          </div>
        </div>`;
      }).join('');

      reminderList.querySelectorAll('[data-done]').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await apiFetch(`/reminders/${btn.dataset.done}/complete`, { method: 'POST' });
            loadReminders();
          } catch (err) { showAlert(alertBox, err.message); }
        });
      });
      reminderList.querySelectorAll('[data-delete]').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await apiFetch(`/reminders/${btn.dataset.delete}`, { method: 'DELETE' });
            loadReminders();
          } catch (err) { showAlert(alertBox, err.message); }
        });
      });
    } catch (err) {
      reminderList.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  loadReminders();
}
