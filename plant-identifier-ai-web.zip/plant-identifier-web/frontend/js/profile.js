/**
 * MODULE - GARDENER PROFILE
 * ---------------------------------------------------------
 */

if (initProtectedPage('profile')) {
  const alertBox = document.getElementById('alertBox');
  const statsRow = document.getElementById('statsRow');
  const profileForm = document.getElementById('profileForm');
  const saveBtn = document.getElementById('saveBtn');

  async function loadProfile() {
    try {
      const { user, stats } = await apiFetch('/users/profile');
      document.getElementById('name').value = user.name || '';
      document.getElementById('gardenerLevel').value = user.gardenerLevel || 'Beginner';
      document.getElementById('bio').value = user.bio || '';
      document.getElementById('emailDisplay').textContent = user.email;
      document.getElementById('joinedDisplay').textContent = formatDate(user.createdAt);
      statsRow.innerHTML = `
        <div class="stat-box"><div class="num">${stats.identifications}</div><div class="label">Identifications</div></div>
        <div class="stat-box"><div class="num">${stats.diagnoses}</div><div class="label">Diagnoses</div></div>
        <div class="stat-box"><div class="num">${stats.reminders}</div><div class="label">Reminders</div></div>
      `;
      Auth.setUser(user);
    } catch (err) {
      showAlert(alertBox, err.message);
    }
  }

  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    alertBox.innerHTML = '';
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span class="spinner"></span> Saving...';

    try {
      const { user } = await apiFetch('/users/profile', {
        method: 'PUT',
        body: {
          name: document.getElementById('name').value.trim(),
          gardenerLevel: document.getElementById('gardenerLevel').value,
          bio: document.getElementById('bio').value.trim()
        }
      });
      Auth.setUser(user);
      alertBox.innerHTML = '<div class="alert alert-success">Profile updated.</div>';
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Changes';
    }
  });

  document.getElementById('logoutBtn2').addEventListener('click', async () => {
    try { await apiFetch('/auth/logout', { method: 'POST' }); } catch (e) { /* ignore */ }
    Auth.clearToken();
    window.location.href = 'login.html';
  });

  loadProfile();
}
