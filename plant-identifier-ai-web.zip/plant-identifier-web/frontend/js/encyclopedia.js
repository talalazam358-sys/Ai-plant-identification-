/**
 * MODULE - PLANT ENCYCLOPEDIA
 * ---------------------------------------------------------
 */

let currentPlants = [];
let encLang = 'en';

if (initProtectedPage('encyclopedia')) {
  const alertBox = document.getElementById('alertBox');
  const searchInput = document.getElementById('searchInput');
  const plantGrid = document.getElementById('plantGrid');
  const detailCard = document.getElementById('detailCard');
  const detailTitle = document.getElementById('detailTitle');
  const detailBody = document.getElementById('detailBody');

  let searchTimer = null;
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => loadPlants(searchInput.value.trim()), 250);
  });

  async function loadPlants(search) {
    try {
      const query = search ? `?search=${encodeURIComponent(search)}` : '';
      const { plants } = await apiFetch(`/encyclopedia${query}`);
      currentPlants = plants;
      renderGrid(plants);
    } catch (err) {
      showAlert(alertBox, err.message);
    }
  }

  function renderGrid(plants) {
    if (plants.length === 0) {
      plantGrid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><div class="icon">🌱</div>No plants matched your search.</div>`;
      return;
    }
    plantGrid.innerHTML = plants.map(p => `
      <div class="card" style="cursor:pointer;margin-bottom:0;" data-plant="${p.id}">
        <h3 style="margin-bottom:2px;">${escapeHtml(p.name)}</h3>
        <p style="font-style:italic;color:var(--ink-soft);margin:0 0 8px;">${escapeHtml(p.scientificName || '')} · ${escapeHtml(p.family || '')}</p>
        <p style="font-size:0.88rem;margin:0;">${escapeHtml((p.description || '').slice(0, 110))}${(p.description || '').length > 110 ? '…' : ''}</p>
      </div>
    `).join('');

    plantGrid.querySelectorAll('[data-plant]').forEach(card => {
      card.addEventListener('click', () => showDetail(card.dataset.plant));
    });
  }

  function showDetail(id) {
    const p = currentPlants.find(x => x.id === id);
    if (!p) return;
    detailTitle.textContent = p.name;
    detailBody.innerHTML = `
      <div class="lang-toggle">
        <button type="button" class="lang-btn ${encLang === 'en' ? 'active' : ''}" data-lang="en">English</button>
        <button type="button" class="lang-btn ${encLang === 'ur' ? 'active' : ''}" data-lang="ur">اردو</button>
      </div>
      <p style="font-style:italic;color:var(--ink-soft);">${escapeHtml(p.scientificName || '')} · ${escapeHtml(p.family || '')}</p>
      <div id="detailLangBody"></div>
    `;
    renderDetailLang(p);
    detailCard.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        encLang = btn.dataset.lang;
        detailCard.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderDetailLang(p);
      });
    });
    detailCard.style.display = 'block';
    detailCard.scrollIntoView({ behavior: 'smooth' });
  }

  function renderDetailLang(p) {
    const body = document.getElementById('detailLangBody');
    const isUrdu = encLang === 'ur';
    const desc = isUrdu ? (p.descriptionUrdu || p.description) : p.description;
    const benefits = isUrdu ? (p.benefitsUrdu || p.benefits) : p.benefits;
    const care = isUrdu ? (p.careGuideUrdu || p.careGuide) : p.careGuide;
    const cls = isUrdu ? 'urdu-text' : '';
    body.innerHTML = `
      <p class="${cls}"><strong>${isUrdu ? 'تفصیل' : 'Description'}:</strong> ${escapeHtml(desc || '—')}</p>
      <p class="${cls}"><strong>${isUrdu ? 'فوائد' : 'Benefits'}:</strong> ${escapeHtml(benefits || '—')}</p>
      <p class="${cls}"><strong>${isUrdu ? 'دیکھ بھال' : 'Care Guide'}:</strong> ${escapeHtml(care || '—')}</p>
    `;
  }

  loadPlants('');
}
