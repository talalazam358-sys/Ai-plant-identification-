/**
 * MODULE - BOTANICAL ESSAY GENERATOR
 * ---------------------------------------------------------
 */

let currentLang = 'en';

if (initProtectedPage('essay')) {
  const alertBox = document.getElementById('alertBox');
  const generateBtn = document.getElementById('generateBtn');
  const resultCard = document.getElementById('resultCard');
  const resultTitle = document.getElementById('resultTitle');
  const resultBody = document.getElementById('resultBody');
  const essayList = document.getElementById('essayList');

  document.querySelectorAll('.lang-toggle button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.lang-toggle button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentLang = btn.dataset.lang;
    });
  });

  generateBtn.addEventListener('click', async () => {
    const topic = document.getElementById('topic').value.trim();
    if (!topic) {
      showAlert(alertBox, 'Please enter a plant or topic name.');
      return;
    }
    alertBox.innerHTML = '';
    generateBtn.disabled = true;
    generateBtn.innerHTML = '<span class="spinner"></span> Writing essay...';
    resultCard.style.display = 'none';

    try {
      const { essay } = await apiFetch('/essay', { method: 'POST', body: { topic, language: currentLang } });
      showEssay(essay);
      loadEssays();
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      generateBtn.disabled = false;
      generateBtn.textContent = 'Generate Essay';
    }
  });

  function showEssay(essay) {
    resultTitle.textContent = `${essay.topic} (${essay.language})`;
    const isUrdu = essay.language === 'Urdu';
    resultBody.innerHTML = `<p class="${isUrdu ? 'urdu-text' : ''}">${escapeHtml(essay.content).replace(/\n/g, '<br>')}</p>`;
    resultCard.style.display = 'block';
  }

  async function loadEssays() {
    try {
      const { essays } = await apiFetch('/essay');
      if (essays.length === 0) {
        essayList.innerHTML = `<div class="empty-state"><div class="icon">📚</div>No essays saved yet.</div>`;
        return;
      }
      essayList.innerHTML = essays.map(e => `
        <div class="list-item">
          <div>
            <strong>${escapeHtml(e.topic)}</strong>
            <div style="font-size:0.82rem;color:var(--ink-soft);">${escapeHtml(e.language)} · ${formatDate(e.createdAt)}</div>
          </div>
          <div style="display:flex;gap:6px;">
            <button class="btn btn-outline btn-sm" data-view="${e.id}">View</button>
            <button class="btn btn-danger btn-sm" data-delete="${e.id}">Delete</button>
          </div>
        </div>
      `).join('');

      essayList.querySelectorAll('[data-view]').forEach(btn => {
        btn.addEventListener('click', () => {
          const essay = essays.find(x => x.id === btn.dataset.view);
          if (essay) { showEssay(essay); window.scrollTo({ top: 0, behavior: 'smooth' }); }
        });
      });
      essayList.querySelectorAll('[data-delete]').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await apiFetch(`/essay/${btn.dataset.delete}`, { method: 'DELETE' });
            loadEssays();
          } catch (err) {
            showAlert(alertBox, err.message);
          }
        });
      });
    } catch (err) {
      essayList.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  loadEssays();
}
