/**
 * MODULE - AI BOTANIST CHAT
 * ---------------------------------------------------------
 */

if (initProtectedPage('chat')) {
  const chatWindow = document.getElementById('chatWindow');
  const chatForm = document.getElementById('chatForm');
  const messageInput = document.getElementById('messageInput');
  const sendBtn = document.getElementById('sendBtn');
  const alertBox = document.getElementById('alertBox');
  const clearBtn = document.getElementById('clearBtn');

  function appendBubble(role, text) {
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${role}`;
    bubble.textContent = text;
    chatWindow.appendChild(bubble);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  async function loadHistory() {
    try {
      const { messages } = await apiFetch('/chat');
      if (messages.length === 0) {
        appendBubble('assistant', "Hi, I'm Sprout 🌱 — your AI botanist. Ask me about watering, pests, soil, or anything plant-related!");
        return;
      }
      messages.forEach(m => appendBubble(m.role, m.text));
    } catch (err) {
      showAlert(alertBox, err.message);
    }
  }

  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = messageInput.value.trim();
    if (!message) return;
    appendBubble('user', message);
    messageInput.value = '';
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<span class="spinner"></span>';
    alertBox.innerHTML = '';

    try {
      const { reply } = await apiFetch('/chat', { method: 'POST', body: { message } });
      appendBubble('assistant', reply);
    } catch (err) {
      showAlert(alertBox, err.message);
    } finally {
      sendBtn.disabled = false;
      sendBtn.textContent = 'Send';
    }
  });

  clearBtn.addEventListener('click', async () => {
    if (!confirm('Clear your entire chat history?')) return;
    try {
      await apiFetch('/chat/clear', { method: 'DELETE' });
      chatWindow.innerHTML = '';
      appendBubble('assistant', "Chat cleared. What would you like to talk about?");
    } catch (err) {
      showAlert(alertBox, err.message);
    }
  });

  loadHistory();
}
