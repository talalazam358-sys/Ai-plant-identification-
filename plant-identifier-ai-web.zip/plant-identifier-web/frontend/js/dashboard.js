/**
 * MODULE - DASHBOARD (HOME)
 * ---------------------------------------------------------
 */

if (initProtectedPage('dashboard')) {
  const user = Auth.getUser();
  document.getElementById('welcomeTitle').textContent = `Welcome back, ${user ? user.name : 'Gardener'} 🌱`;

  const TILES = [
    { href: 'identify.html', icon: '🔍', title: 'Identify a Plant', desc: 'Snap or upload a photo to instantly identify any plant.' },
    { href: 'disease.html', icon: '🩺', title: 'Plant Doctor', desc: 'Diagnose diseases and pests from a photo.' },
    { href: 'essay.html', icon: '📖', title: 'Botanical Essay', desc: 'Generate essays in English or Urdu.' },
    { href: 'chat.html', icon: '💬', title: 'Botanist Chat', desc: 'Ask Sprout, your 24/7 AI botanist, anything.' },
    { href: 'reminders.html', icon: '⏰', title: 'Care Reminders', desc: 'Never miss a watering or feeding again.' },
    { href: 'encyclopedia.html', icon: '🌿', title: 'Encyclopedia', desc: 'Browse a bilingual plant reference library.' }
  ];

  const tilesEl = document.getElementById('moduleTiles');
  tilesEl.innerHTML = TILES.map(t => `
    <a href="${t.href}" class="card" style="text-decoration:none;display:block;">
      <div style="font-size:1.8rem;">${t.icon}</div>
      <h3 style="margin-top:8px;">${t.title}</h3>
      <p style="color:var(--ink-soft);margin:0;font-size:0.88rem;">${t.desc}</p>
    </a>
  `).join('');

  loadStats();
  loadUpcoming();
}

async function loadStats() {
  const statsRow = document.getElementById('statsRow');
  try {
    const { stats } = await apiFetch('/users/profile');
    statsRow.innerHTML = `
      <div class="stat-box"><div class="num">${stats.identifications}</div><div class="label">Plants Identified</div></div>
      <div class="stat-box"><div class="num">${stats.diagnoses}</div><div class="label">Diagnoses Run</div></div>
      <div class="stat-box"><div class="num">${stats.reminders}</div><div class="label">Active Reminders</div></div>
    `;
  } catch (err) {
    statsRow.innerHTML = `<div class="alert alert-error" style="grid-column:1/-1;">${escapeHtml(err.message)}</div>`;
  }
}

async function loadUpcoming() {
  const list = document.getElementById('upcomingList');
  try {
    const { reminders } = await apiFetch('/reminders');
    const upcoming = reminders.filter(r => r.active).slice(0, 5);
    if (upcoming.length === 0) {
      list.innerHTML = `<div class="empty-state"><div class="icon">🌼</div>No reminders yet. <a href="reminders.html">Add one</a> to keep your plants on schedule.</div>`;
      return;
    }
    list.innerHTML = upcoming.map(r => `
      <div class="list-item">
        <div>
          <strong>${escapeHtml(r.plantName)}</strong>
          <div style="font-size:0.82rem;color:var(--ink-soft);">${escapeHtml(r.type)} · due ${formatDate(r.nextDue)}</div>
        </div>
      </div>
    `).join('');
  } catch (err) {
    list.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
  }
}
