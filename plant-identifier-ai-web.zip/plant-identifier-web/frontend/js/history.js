/**
 * MODULE - HISTORY
 * ---------------------------------------------------------
 */

let currentFilter = 'all';

if (initProtectedPage('history')) {
  const alertBox = document.getElementById('alertBox');
  const historyList = document.getElementById('historyList');

  document.querySelectorAll('#filterToggle button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#filterToggle button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      loadHistory();
    });
  });

  function severityBadgeClass(sev) {
    const s = (sev || '').toLowerCase();
    if (s.includes('high')) return 'badge-high';
    if (s.includes('moderate')) return 'badge-moderate';
    return 'badge-low';
  }

  async function loadHistory() {
    historyList.innerHTML = '<p style="color:var(--ink-soft);">Loading...</p>';
    try {
      const query = currentFilter === 'all' ? '' : `?type=${currentFilter}`;
      const { history } = await apiFetch(`/history${query}`);
      if (history.length === 0) {
        historyList.innerHTML = `<div class="empty-state"><div class="icon">🗂️</div>Nothing here yet. Try <a href="identify.html">identifying</a> or <a href="disease.html">diagnosing</a> a plant.</div>`;
        return;
      }
      historyList.innerHTML = history.map(h => {
        const r = h.result || {};
        if (h.type === 'identify') {
          return `
          <div class="list-item">
            <div>
              <strong>🔍 ${escapeHtml(r.name || 'Unknown plant')}</strong>
              <div style="font-size:0.82rem;color:var(--ink-soft);font-style:italic;">${escapeHtml(r.scientificName || '')} · ${formatDateTime(h.createdAt)}</div>
            </div>
            <button class="btn btn-danger btn-sm" data-delete="${h.id}">Delete</button>
          </div>`;
        }
        return `
        <div class="list-item">
          <div>
            <strong>🩺 ${escapeHtml(r.diseaseName || 'Unknown issue')}</strong>
            <div style="font-size:0.82rem;color:var(--ink-soft);">
              <span class="badge ${severityBadgeClass(r.severity)}">${escapeHtml(r.severity || '')}</span>
              ${formatDateTime(h.createdAt)}
            </div>
          </div>
          <button class="btn btn-danger btn-sm" data-delete="${h.id}">Delete</button>
        </div>`;
      }).join('');

      historyList.querySelectorAll('[data-delete]').forEach(btn => {
        btn.addEventListener('click', async () => {
          try {
            await apiFetch(`/history/${btn.dataset.delete}`, { method: 'DELETE' });
            loadHistory();
          } catch (err) { showAlert(alertBox, err.message); }
        });
      });
    } catch (err) {
      historyList.innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  loadHistory();
}
