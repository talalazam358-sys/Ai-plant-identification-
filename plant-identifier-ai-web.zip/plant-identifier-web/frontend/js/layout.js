/**
 * SHARED MODULE - LAYOUT / AUTH GUARD
 * ---------------------------------------------------------
 * Injects the topbar + sidebar (with links to all 12 modules)
 * into any protected page, and redirects to login.html if the
 * visitor has no valid session token.
 * ---------------------------------------------------------
 */

const NAV_LINKS = [
  { href: 'dashboard.html', icon: '🏠', label: 'Dashboard', key: 'dashboard' },
  { href: 'identify.html', icon: '🔍', label: 'Identify Plant', key: 'identify' },
  { href: 'disease.html', icon: '🩺', label: 'Plant Doctor', key: 'disease' },
  { href: 'essay.html', icon: '📖', label: 'Botanical Essay', key: 'essay' },
  { href: 'chat.html', icon: '💬', label: 'Botanist Chat', key: 'chat' },
  { href: 'reminders.html', icon: '⏰', label: 'Care Reminders', key: 'reminders' },
  { href: 'history.html', icon: '🗂️', label: 'History', key: 'history' },
  { href: 'encyclopedia.html', icon: '🌿', label: 'Encyclopedia', key: 'encyclopedia' },
  { href: 'profile.html', icon: '👤', label: 'My Profile', key: 'profile' }
];

function guardAuth() {
  if (!Auth.isLoggedIn()) {
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

function renderLayout(activeKey) {
  const user = Auth.getUser();
  const initials = (user && user.name ? user.name.trim().charAt(0).toUpperCase() : '?');

  const topbar = document.createElement('header');
  topbar.className = 'topbar';
  topbar.innerHTML = `
    <a href="dashboard.html" class="brand">
      <img src="assets/logo.svg" class="brand-logo" alt="Plant Identifier AI logo" />
      <span>
        <span class="brand-name">Plant Identifier AI</span>
        <span class="brand-tag">Classic Botanical Edition</span>
      </span>
    </a>
    <div class="topbar-user">
      <span>${user ? escapeHtml(user.name) : ''}</span>
      <div class="avatar-badge">${initials}</div>
      <button class="btn btn-outline btn-sm" id="logoutBtn" style="color:#faf6ec;border-color:#d9ac67;">Log out</button>
    </div>
  `;

  const shell = document.createElement('div');
  shell.className = 'app-shell';

  const sidebar = document.createElement('aside');
  sidebar.className = 'sidebar';
  const nav = document.createElement('nav');
  NAV_LINKS.forEach(link => {
    const a = document.createElement('a');
    a.href = link.href;
    a.className = link.key === activeKey ? 'active' : '';
    a.innerHTML = `<span class="icon">${link.icon}</span><span>${link.label}</span>`;
    nav.appendChild(a);
  });
  sidebar.appendChild(nav);

  const main = document.createElement('main');
  main.className = 'main-content';
  main.id = 'mainContent';

  // Move any existing body content into <main>
  while (document.body.firstChild) {
    main.appendChild(document.body.firstChild);
  }

  shell.appendChild(sidebar);
  shell.appendChild(main);

  document.body.appendChild(topbar);
  document.body.appendChild(shell);

  document.getElementById('logoutBtn').addEventListener('click', async () => {
    try { await apiFetch('/auth/logout', { method: 'POST' }); } catch (e) { /* ignore */ }
    Auth.clearToken();
    window.location.href = 'login.html';
  });
}

/** Call at the top of every protected page's script */
function initProtectedPage(activeKey) {
  if (!guardAuth()) return false;
  renderLayout(activeKey);
  return true;
}
